clc;
clear all;
clc;clear all;close all;
%%System parameter
SNR=1:2:30;
Trans_Antenna_Num = 1;
Recei_Antenna_Num = 1;
CellNum = 3;
Nfft = 2048;pilotfrequency= Nfft/8;
NusedSc = 12*111;
Ts = 1/(Nfft*15000);
Ncp_normal = round(4.6875e-6/Ts);
Ncp_extend = round(16.67e-6/Ts);
N_RB_min = 6;
N_RB_max = 111;
N_RBsc = 12;
Nsym_normal = 7;
Nsym_extend = 6;
Nslot_perFrame = 20;
%%User parameter
Current_cell = 1;
CP_idx = 0;    % 0 for normal CP, and 1 for extend CP
Num_UsedSlot = 2;
Num_UsedRB = 10;
UsedRB_idx = 1:10;%sort(randint(1,Num_UsedRB,111)+1);
if CP_idx == 0
    Ncp = Ncp_normal; Nsym_slot = Nsym_normal;
elseif CP_idx == 1
    Ncp = Ncp_extend; Nsym_slot = Nsym_extend;
end
rand('seed',1);
PowerList = [10];   %      Power from different Bs
ChMSE_LS = 0; ChMSE_LMMSE=0;
%%% Main function %%%%%%
beta=17/9;
Tr_F_data = zeros(Nfft,Nsym_slot*Num_UsedSlot);
UsedF_data = zeros(N_RBsc*N_RB_max,Nsym_slot*Num_UsedSlot);
for RB_idx = UsedRB_idx
    source = qammod(randint(N_RBsc,Nsym_slot*Num_UsedSlot,4),4)/sqrt(2);
    UsedF_data((RB_idx-1)*N_RBsc+1:RB_idx*N_RBsc,:) = source;
end
Tr_F_data= UsedF_data;          %Mapping the frequency domain data
Tr_T_data = ifft(ifftshift(Tr_F_data))*sqrt(2048);
%     Tr_T_data = [Tr_T_data(end-Ncp+1:end,:);Tr_T_data];         %add cp
Tr_T_data = reshape(Tr_T_data ,1,[]);

Tr_T_data = Tr_T_data.*10.^(PowerList/20);    %trans power
H=sqrt(0.5)*(randn(size(Tr_T_data))+sqrt(-1)*randn(size(Tr_T_data)));

Re_T_data = filter(H,1,Tr_T_data);    %pass ch;
Noise = sqrt(12*10/2048)*sqrt(0.5)*(randn(size(Re_T_data))+sqrt(-1)*randn(size(Re_T_data)));
%% receiver
X=Tr_T_data;

Re_T_signal = Re_T_data+Noise;   %combin the signal from different Bs
Y=Re_T_signal;
PLoc = 1:pilotfrequency:Nfft; % location of pilots
% u=rand(2048,2048);
% F=fft(u)*inv(u);% 'F' is the twiddle factor matrix..

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
for n=1:length(SNR)
    TxP = Tr_T_data(:,PLoc); % transmitted pilots
    RxP = Re_T_signal(:,PLoc); % received pilots
    % Least-Square Estimation
    H_LS= RxP./TxP; % LS channel estimation
    H_hat=H(:,PLoc);
    ChMSE_LS = ChMSE_LS -((H_hat - H_LS)*(H_hat-H_LS)');
    %     A=Y./X;
    %     ChMSE_LS = ChMSE_LS +((H - A)*(H-A)')/Nfft;
    SNRdB=SNR(n);Ip=eye(8);
    %
    
    Rhhp = H*H';
    Rhphp=H_hat*H_hat';
    W = Rhhp*(Rhphp+(beta/SNRdB)*Ip);
    HhatLMMSE = H_LS*W;
    ChMSE_LMMSE = ChMSE_LMMSE - ((H_hat -HhatLMMSE)*(H_hat-HhatLMMSE)');
    % %Evaluating the mean squared error for the LS estimator..
    % mean_squared_error_ls=LS_MSE_calc(X,H,Y);
    % %Evaluating the mean squared error for the MMSE estimator..
    
    
    mmse_mse(n)=ChMSE_LMMSE;
    ls_mse(n)=ChMSE_LS;
end;


% mmse_mse_ave=mean(mmse_mse);

% set(0,'DefaultAxesFontSize', 16)
% %Now just the display part.....
plot(ls_mse,'r-o');hold on;
plot(mmse_mse)
% grid on;
% xlabel('SNR in DB');
% ylabel('Mean Squared Error');
% title('PLOT OF SNR V/S MSE FOR AN OFDM SYSTEM WITH MMSE/LS ESTIMATOR BASED RECEIVERS');
% legend('LS','MMSE');
%
