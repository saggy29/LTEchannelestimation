%% define parameters
clc;
clear all
MC=1;m=10;
%%System parameter
SNR=0:2:30;
Trans_Antenna_Num = 1;
Recei_Antenna_Num = 1;
CellNum = 3;
Nfft = 2048;
NusedSc = 12*111;
Ts = 1/(Nfft*15000);
Ncp_normal = round(4.6875e-6/Ts);
Ncp_extend = round(16.67e-6/Ts);
N_RB_min = 6;
N_RB_max = 111;
N_RBsc = 12;
Nsym_normal = 7;
Nsym_extend = 6;
Nslot_perFrame = 20;
%%User parameter
CP_idx = 0;    % 0 for normal CP, and 1 for extend CP
Num_UsedSlot = 2;
Num_UsedRB = 10;
UsedRB_idx = 1:10;%sort(randint(1,Num_UsedRB,111)+1);
if CP_idx == 0
    Ncp = Ncp_normal; Nsym_slot = Nsym_normal;
elseif CP_idx == 1
    Ncp = Ncp_extend; Nsym_slot = Nsym_extend;
end
rand('seed',1);
PowerList = [10];   %      Power from different Bs

%M=input( ' Constellation Order M = ' ) ;
M=16;
pilotFrequency= Nfft/8;
E=2;
%L=input(' channel Length (number of taps) = ');
L=1;

%% data generation
Tr_F_data = zeros(Nfft,Nsym_slot*Num_UsedSlot);
UsedF_data = zeros(N_RBsc*N_RB_max,Nsym_slot*Num_UsedSlot);
for RB_idx =1:10
    source = qammod(randint(N_RBsc,Nsym_slot*Num_UsedSlot,4),4)/sqrt(2);
    UsedF_data((RB_idx-1)*N_RBsc+1:RB_idx*N_RBsc,:) = source;
end
Tr_F_data=UsedF_data;
Tr_T_data = ifft(ifftshift(Tr_F_data))*sqrt(Nfft);
Tr_T_data = [Tr_T_data(end-Ncp+1:end,:);Tr_T_data];         %add cp
Tr_T_data = Tr_T_data.*10.^(PowerList/20);    %trans power

%% mapping (baseband modulation )
D_Mod=Tr_T_data;
%% serial to parallel
D_Mod_serial=D_Mod.';
%% specify Pilot & Date Locations
PLoc = 1:pilotFrequency:Nfft; % location of pilots
DLoc = setxor(1:Nfft,PLoc); % location of data
%% Pilot Insertion
D_Mod_serial(PLoc)=D_Mod_serial(PLoc);

%% inverse discret Fourier transform (IFFT)
%  Amplitude Modulation
d_ifft=ifft(D_Mod_serial);
%% parallel to serail
d_ifft_parallel=d_ifft.';
% %% Adding Cyclic Prefix
% CP_part=d_ifft_parallel(:,end-Ncp+1:end); % this is the Cyclic Prefix part to be appended.
 ofdm= [d_ifft_parallel];
%% generating random channel
h= randn(1,L) + 1j * randn(1,L);
h = h./norm(h); % normalization
H = fft(h,Nfft); % Frequency-Domain Channel
d_channelled = filter(h,1,ofdm.').'; % channel effect
channel_length = length(h); % True channel and its time-domain length
H_power_dB = 10*log10(abs(H.*conj(H))); % True channel power in dB
%% add noise
count=0;
snr_vector=0:4:40;
for snr=snr_vector
    SNR = snr + 10*log10(log2(M));
    count=count+1 ;
    disp(['step: ',num2str(count),' of: ',num2str(length(snr_vector))])
    ChMSE_LS = 0;
    ChMSE_LMMSE=0;
    for mc = 1:MC
        ofdm_noisy_NoCH=awgn(ofdm,SNR,'measured' ) ;
        ofdm_noisy_with_chann=awgn(d_channelled,SNR,'measured' ) ;
        %% receiver
        %Remove Cyclic Prefix
        ofdm_cp_removed_NoCH=ofdm_noisy_NoCH(end-Ncp+1:end,:);
        ofdm_cp_removed_with_chann=ofdm_noisy_with_chann(end-Ncp+1:end,:);
        % serial to parallel
        ofdm_parallel_NoCH=ofdm_cp_removed_NoCH.';
        ofdm_parallel_chann=ofdm_cp_removed_with_chann.';
        %% Discret Fourier transform (FFT)
        %  Amplitude Demodulation
        d_parallel_fft_NoCH=fft(ofdm_parallel_NoCH) ;
        d_parallel_fft_channel=fft(ofdm_parallel_chann) ;
        
        
        %% channel estimation
        % Extracting received pilots
        TxP = D_Mod_serial(PLoc); % trnasmitted pilots
        RxP = d_parallel_fft_channel(PLoc); % received pilots
        % Least-Square Estimation
        Hpilot_LS= RxP./TxP; % LS channel estimation
        % MMSE Estimation:-
        for r=1:m
            H_MMSE(r) = MMSE(RxP(r),TxP(r),Nfft,pilotFrequency,h,SNR);
        end
        
        % Interpolation p--->N
        for q=1:m
            HData_LS(q) = interpolate(Hpilot_LS(q).',PLoc,Nfft,'spline'); % Linear/Spline interpolation
        end
        %% parallel to serial
        HData_LS_parallel1=HData_LS.';
        HData_MMSE_parallel1=H_MMSE.';
        
        
        %% demapping
        d_received_NoCH=demodulate(Rx,(d_parallel_fft_NoCH.')) ; % No Channel
        d_received_chann_LS=demodulate(Rx,(d_parallel_fft_channel.')./HData_LS_parallel1) ; % LS channel estimation
        d_received_chann_MMSE=demodulate(Rx,(d_parallel_fft_channel.')./(HData_MMSE_parallel1)) ; % MMSE channel estimation
        %% Removing Pilots from received data and original data
        D_no_pilots=D(:,DLoc); % removing pilots from D
        Rec_d_NoCH=d_received_NoCH(:,DLoc); % removing pilots from d_received_NoCH
        Rec_d_LS=d_received_chann_LS(:,DLoc); % removing pilots from d_received_chann_LS
        Rec_d_MMSE=d_received_chann_MMSE(:,DLoc); % removing pilots from d_received_chann_MMSE
        %% Calculating BER
        [r_NoCH]=symerr(D_no_pilots,Rec_d_NoCH) ;
        [r_LS]=symerr(D_no_pilots,Rec_d_LS) ;
        [r_MMSE]=symerr(D_no_pilots,Rec_d_MMSE) ;
        ChMSE_LS = ChMSE_LS +r_LS;
        ChMSE_LMMSE = ChMSE_LMMSE+r_MMSE;
    end
    ChEstLS(count) = ChMSE_LS/MC;
    ChEstMMSE(count)=ChMSE_LMMSE/MC;
end
figure;hold on
%semilogy(snr_vector,r_NoCH,'-+');
semilogy(snr_vector,ChEstLS,'g-o');
semilogy(snr_vector,ChEstMMSE,'r-s');
legend('LS CE','MMSE CE');
grid ;
hold off;
H_power_esti_dB_LS     = 10*log10(abs(HData_LS_parallel1.*conj(HData_LS_parallel1))); % Estimated channel power in dB
H_power_esti_dB_MMSE     = 10*log10(abs(HData_MMSE_parallel1.*conj(HData_MMSE_parallel1))); % Estimated channel power in dB
figure;hold on;
plot(H_power_dB(1:8:end),'+k','LineWidth',3);
plot(H_power_esti_dB_LS(1,(1:8:end)),'or','LineWidth',3);
plot(H_power_esti_dB_MMSE(1,(1:8:end)),'Sb','LineWidth',1);
title('ACTUAL AND ESTIMATED CHANNELS');
xlabel('Time in samples');
ylabel('Magnitude of coefficients');
legend('Actual','estimated LSE','estimated MMSE')
