function ms_error=MMSE_MSE_calc(SNR,H);
        Rhh = H*H';
        W = Rhh/(Rhh+eye(Nfft));
        HhatLMMSE = W*HhatLS;
        ChMSE_LMMSE = ChMSE_LMMSE + ((H -HhatLMMSE)'*(H-HhatLMMSE))/nFFT;
end