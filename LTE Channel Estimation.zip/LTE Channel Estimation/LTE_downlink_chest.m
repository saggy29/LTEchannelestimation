%Channel estimation
clear all
clc
TX_Num= 1;     % no of antenna
RX_Num =1;      % no of receiving antenna      
M_RB_PDSCH=10;  % resource block
N_sc_RB=12;      % total no of subcarrier in resource block
DFT_Size =M_RB_PDSCH*N_sc_RB;       % DFT size
FFT_Size = 2048;                    % No of FFT symbol
CP_Size =160;                       % Cyclic Prefix
n_cs=[0 6];                         % 
alpha=2*pi*n_cs/12;
sq2=sqrt(2);
h_pdp=[1,0.5,0.25,0.125,0.0625]*sq2;
L=length(h_pdp);
F=zeros(DFT_Size,FFT_Size);
for i=1:DFT_Size
for j=1:FFT_Size
F(i,j)=exp(-1j*2*pi*(i-1)*(j-1)/FFT_Size);
end
end
L_TWD=floor(1.2*L);
index=zeros(1,TX_Num*L_TWD);
for n=1:TX_Num
index((n-1)*L_TWD+1:n*L_TWD)=n_cs(n)*FFT_Size/12+(1:L_TWD);
end
SNR=[0:5:30];
Len_SNR=length(SNR);
pilot = [06,12,03,09,06,12,03,09];
tx_syms_map=zeros(TX_Num,FFT_Size);
for n=1:TX_Num
tx_syms_map(n,1:DFT_Size)=exp(1j*alpha(n)*[0:DFT_Size-1]).*pilot;
end
tx_syms=zeros(TX_Num,FFT_Size);
for n=1:TX_Num
tx_syms(n,:)=ifft(tx_syms_map(n,:),FFT_Size);
end
tx_syms_ACP=[tx_syms(:,FFT_Size-CP_Size+1:end) tx_syms];
MSE=zeros(2,Len_SNR);
Num_syms=1000;
for nsnr=1:Len_SNR
for sym_dex=1:Num_syms
h=zeros(RX_Num*TX_Num,L);
H_ideal=zeros(RX_Num,TX_Num*DFT_Size);
sig_fad=zeros(RX_Num,FFT_Size+CP_Size);
for n=1:RX_Num
for m=1:TX_Num
temp=h_pdp.*[randn(1,L)+1j*randn(1,L)]/sq2;
sig_fad(n,:)=sig_fad(n,:)+filter(temp,1,tx_syms_ACP(m,:));
h((n-1)*TX_Num+m,:)=temp;
H=fft(temp,FFT_Size);
H_ideal(n,(m-1)*DFT_Size+1:m*DFT_Size)=H(1:DFT_Size);
end
end
sig_rx=zeros(RX_Num,FFT_Size+CP_Size);
sigma=zeros(1,RX_Num);
for n=1:RX_Num
sig_rx(n,:)=awgn(sig_fad(n,:),SNR(nsnr),'measured');
sigma(n)=abs(norm(sig_rx(n,:))^2-norm(sig_fad(n,:))^2);
end
sig_rx_RCP=sig_rx(:,CP_Size+1:end);
SigRxed_Fre=fft(sig_rx_RCP,FFT_Size,2);
Y=SigRxed_Fre(:,1:DFT_Size);
H_LS=zeros(RX_Num,DFT_Size);
for m=1:RX_Num
H_LS(m,1:DFT_Size)=Y(m,:).*conj(pilot.');
end
for alg=1:2
H_est=zeros(RX_Num,TX_Num*DFT_Size);
for m=1:RX_Num
if(alg==1)
g=pinv(F(:,index))*H_LS(m,:).';  % LS estimation
else
g=inv(F(:,index)'*F(:,index)+sigma(m)*eye(TX_Num*L_TWD))*F(:,index)'*H_LS(m,:).'; % MMSE estimation
end
for n=1:TX_Num
temp=g((n-1)*L_TWD+1:n*L_TWD).';
H=fft(temp,FFT_Size);
H_est(m,(n-1)*DFT_Size+1:n*DFT_Size)=H(1:DFT_Size);
end
end
MSE(alg,nsnr)=MSE(alg,nsnr)+sum(sum(abs(H_ideal- H_est).^2))/(RX_Num*TX_Num*DFT_Size);
end
end
end
MSE=MSE/Num_syms;
figure
semilogy(SNR,MSE)
axis([0 25 10^-5 0.5])
grid on
xlabel('SNR(dB)')
ylabel('MSE')
legend('LS','MMSE')
title('Channel estimation algorithms for SISO');